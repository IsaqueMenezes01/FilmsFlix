const populares=[
  { 
    id: '1',
    nome: 'Guilty Party',
    imagem:'./imagens/series/guilty_party.jpg',
    genero: 'Série',
    link: '../links/serie/guilty-party.html',
  },
   { 
    id: '2',
    nome: 'Ghost Busters Mais Além',
    imagem:'./imagens/comedia/ghost.jpg',
    genero: 'Comédia',
    link: '../links/comedia/ghostbusters.html',
  },
   { 
    id: '3' ,
    nome: 'Pantera Negra',
    imagem: './imagens/heroi/pantera_negra.jpg',
    genero: 'héroi',
    link: '../links/heroi/pantera-negra.html',
  },
   { 
    id: '4',
    nome: 'Hometown cha cha cha',
    imagem:'./imagens/series/hometown cha cha cha.jpg',
    genero: 'Série',
    link: '../links/serie/hometown.html',
  },
  { 
    id: '5',
    nome: 'Alerta Vermelho',
    imagem:'./imagens/crime/rednotice.jpg',
    genero: 'Crime',
    link: '../links/acao/alerta.html',
  }
];
export default populares;
